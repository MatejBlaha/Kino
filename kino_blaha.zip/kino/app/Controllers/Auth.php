<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Libraries\Hash;

class Auth extends BaseController
{
    public function __construct(){
        helper(['url','form']);
    }
    public function login()
    {
        return view('auth/login');
    }
    public function register()
    {
        return view('auth/register');
    }
    public function save()
    {
    

//   $validation = $this->validate([
//           'email' =>'required|valid_email|is_unique[users.email]',
//           'heslo' =>'required',
//          'zheslo' =>'required|matches[heslo]', 
//   ]);
    $validation = $this->validate([

        'email'=>[
            'rules'=>'required|valid_email|is_unique[users.email]',
            'errors'=>[
                'required'=>'Pro registraci je potřeba váš email',
                'valid_email'=>'Neplatný email',
                'is_unique'=>'Tento email byl již zaregistrován',
            ]
            ],
        'password'=>[
            'rules'=>'required',
            'errors'=>[
                'required'=>'Pro registraci je potřeba nastavit heslo',
            ]
            ],
        'zheslo'=>[
            'rules'=>'required|matches[password]',
            'errors'=>[
                'required'=>'Zopakujte prosím heslo',
                'matches[password]'=>'hesla se neshodují',
            ]
            ],
        ]);

    if(!$validation){
        return view('auth/register',['validation'=>$this->validator]);
    }else{
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $values = [
            'email'=>$email,
            'password'=>Hash::make($password),
        ];

            $usersModel = new \App\Models\UsersModel();
            $quety = $usersModel->insert($values);
            if(!$query){
                return redirect()->back()->with('fail', 'Něco je blbě O_O');
               // return redirect()->('register')->with('fail', 'Něco je blbě O_O');
            }else{
                return redirect()->to('register')->with('success', 'Úspěšná registrace');
            }
        }
    }

    function check(){
        $validation = $this->validate([
            'email'=>[
                'rules'=>'required|valid_email|is_not_unique[users.email]',
                'errors'=>[
                    'required'=>'Je vyžadován email',
                    'valid_email'=>'Neplatný email',
                    'is_not_unique'=>'Tento email není zaregistrován',

                ]
            ],
            'password'=>[
                'rules'=>'required',
                'errors'=>[
                    'required'=>'Je vyžadováno heslo',
                ]
            ]
        ]);
        if(!$validation){
            return view('Auth/login',['validation'=>$this->validator]);
        }else{
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            $usersModel = new \App\Models\UsersModel();
            $user_info = $usersModel->where('email', $email)->first();
            $check_password = Hash::check($password, $user_info['password']);

        if(!$check_password){
            session()->setFlashdata('fail', 'Incorrect password');
            return redirect()->to('/auth')->withInput();
        }else{
            $user_id = $user_info['id'];
            session()->set('loggedUser', $user_id);
            return redirect()->to('/dashboard');
            
            }
        }
    }
}