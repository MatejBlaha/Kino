<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		return view('welcome_message');
		$this->load->view('pages/header');
		$this->load->view('pages/footer');
		$this->load->view('pages/nav');
		$this->load->view('pages/pridat');

	}

	public function form()
{

	helper(['form', 'url']);

	$this->ionAuth = new \IonAuth\Libraries\IonAuth(); 

	if ( $this->ionAuth->loggedIn() ) {

		$error = $this->validate([
			'nazev_filmu'	=>	'required',
			'jazyk'			=>	'required',
			'delka'			=>	'required'
		]);
		
		if(!$error)
		{
			echo view('layout/header_loggedIn');
			echo view('content/form', ['error' 	=> $this->validator]);
			echo view('layout/footer');
		}
		else{
			
			$db = db_connect();
			$kino_model = new Kino_model($db);

			$kino_model->save(
			$d = $this->request->getVar('delka'),
			$z = $this->request->getVar('druh'),
			$t = $this->request->getVar('typ'),
			$n = $this->request->getVar('nazev_filmu'),
			$j = $this->request->getVar('jazyk'),
			$na = $this->request->getVar('nazev_alt'),
			$ja = $this->request->getVar('jazyk_alt'),
				);
		echo view('pages/header');
		echo view('pages/pridat');
		echo view('pages/footer');
		}
	}
	else 
		
	
	throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        
    }

}
