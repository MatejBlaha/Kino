<div id="container_style" class="container"> 
      
    <?php $validation = \Config\Services::validation();?>
    
    <form action="<?= base_url("form_submit"); ?>" method="post">
    <div class="form-group">
        <div class="row">
            <div class="col">
                <label for="nazev_filmu">Název filmu</label>
                <input type="input" class="form-control" name="nazev_filmu">
                <?php 
                    if($validation->getError('nazev_filmu')){
                        echo '<div class="alert alert-danger mt-2">'.$validation->getError('nazev_filmu').'</div>';
                    }
                ?>
            </div>
            <div class="col">
                <label for="jazyk">Jazyk</label>
                <input type="input" class="form-control" name="jazyk">
                <?php 
                    if($validation->getError('jazyk')){
                        echo '<div class="alert alert-danger mt-2">'.$validation->getError('jazyk').'</div>';
                    }
                    ?>
            </div>
         </div>
    </div>
    <div class="form-group">
    <div class="row">
            <div class="col">
                <label for="nazev_alt">Druhý název</label>
                     <input type="input" class="form-control" name="nazev_alt">
                <?php 
            if($validation->getError('nazev_alt')){
                echo '<div class="alert alert-danger mt-2">'.$validation->getError('nazev_alt').'</div>';
            }
        ?>
            </div>
            <div class="col">
                <label for="jazyk_alt">Jazyk</label>
                    <input type="input" class="form-control" name="jazyk_alt">
                <?php 
            if($validation->getError('jazyk_alt')){
                echo '<div class="alert alert-danger mt-2">'.$validation->getError('jazyk_alt').'</div>';
            }
        ?>
            </div>
         </div>
    </div>
    <div class="form-group">
        <label for="delka">Délka filmu</label>
            <input type="input" class="form-control" name="delka">
        <?php 
            if($validation->getError('delka')){
                echo '<div class="alert alert-danger mt-2">'.$validation->getError('delka').'</div>';
            }
        ?>
    </div>
    <div class="form-group">   
        <label for="typ">Typ filmu</label>
        <select name="typ"  class="form-control">
            <option value="2">Hraný</option>
                <option value="1">Animovaný</option>
        </select>
    </div>
    <div class="form-group">   
        <label for="druh">Žánr filmu</label>
        <select name="druh"  class="form-control">
            <option value="1">Rodinný</option>
            <option value="2">Drama</option>
            <option value="3">Sci-fi</option>
            <option value="4">Thriller</option>
            <option value="5">Komedie</option>
        </select>
    </div>
    <button type="submit"  name='potvrdit' value='Submit' class="btn btn-primary">Přidej</button>
    </form>
    
</div>