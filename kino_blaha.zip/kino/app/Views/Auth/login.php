<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-AU-Compatible" content="ie=edge">
    <title> Sign in </title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= base_url('bootstrap/css/bootstrap.min.css') ?>">
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Kino Staré Město</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">Registrace</a></li>
      <li><a href="#">Přihlášní</a></li>
      <li><a href="#">Přídání filmu</a></li>
      <li><a href="#">Seznam filmů</a></li>
    </ul>
  </div>
</nav>

<div class="container">
    <div class="row" style="margin-top:45px">
        <div class="col-md-4 col-md-offset-4">
            <h4>Přihlášení</h4>
            <form action="<?= base_url('auth/check')?>" method="post">
            <?= csrf_field(); ?>

            <?php if(!empty(session()->getFlashdata('fail'))) : ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('fail'); ?></div>
                <?php endif ?>
                <div class="form-group">
                    <label for="">Email:</label>
                    <input type="text" class="form-control" name="email" placeholder="Sem napište svůj email" value="<?= set_value('email') ?>">
                    <span class="text-danger"><?= isset($validation) ? display_error($validation, 'email'): '' ?></span>
                </div>
                <div class="form-group">
                    <label for="">password:</label>
                    <input type="text" class="form-control" name="password" placeholder="Sem napište své password">
                    <span class="text-danger"><?= isset($validation) ? display_error($validation, 'password'): '' ?></span>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary btn-block" type="submit">Přihlásit se</button>       
                </div>
                <br>
                <a href="<?=site_url('uth/register');?>">Nemáš snad účet? XD</a>
        </div>
    </div>
</div>

</body>
</html>