<?php

namespace App\Controllers;

use \App\Models\kino_vypis;

class Home extends BaseController
{
	public function index()
	{
		$this->ionAuth = new \IonAuth\Libraries\IonAuth(); 
		if(!$this->ionAuth->loggedIn())echo view('pages/header');
		else echo view('pages/header_logOut');
		echo view('pages/home');
		echo view('pages/footer');
	}

	public function zmenit()
    {
       $this->ionAuth = new \IonAuth\Libraries\IonAuth(); 

        $db = db_connect();
       $kino_model = new kino_vypis($db);

       if ( $this->ionAuth->loggedIn() ) {


                $data['zmenit'] = $kino_model->ziskejFilmy();

               echo view('pages/header');
               echo view('pages/vypis', $data);
               echo view('pages/footer');
           }
       else 

       throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

   }

	public function pridat()
{

    $this->ionAuth = new \IonAuth\Libraries\IonAuth(); 

    if ( $this->ionAuth->loggedIn() ) {

        $error = $this->validate([
            'delka'            =>    'required'
        ]);

        if(!$error)
        {
            echo view('pages/header');
            echo view('pages/pridat', ['error'     => $this->validator]);
            echo view('pages/footer');
        }
        else{

            $db = db_connect();
            $kino_model = new kino_vypis($db);

            $kino_model->ulozit(
                $d = $this->request->getVar('delka'),
                $z = $this->request->getVar('druh'),
                $t = $this->request->getVar('typ'),
                $n = $this->request->getVar('nazev_filmu'),
                $j = $this->request->getVar('jazyk'),
                $na = $this->request->getVar('nazev_alt'),
                $ja = $this->request->getVar('jazyk_alt'),
            );

            echo view('pages/header');
            echo view('pages/home');
            echo view('pages/footer');
        }
    }
    else 


    throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();

    }
}

