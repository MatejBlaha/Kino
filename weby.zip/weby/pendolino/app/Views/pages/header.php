<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>


<nav class="navbar navbar-primary">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?php echo base_url('/') ?>">Kino Staré Město</a>
    </div>
    <ul class="nav navbar-nav">
      <li ><a href="<?php echo base_url('/') ?>">Home</a></li>
      <li><a href="<?php echo base_url('auth/login') ?>">Přihlášní</a></li>
    </ul>
  </div>
</nav>


</body>
</html>
