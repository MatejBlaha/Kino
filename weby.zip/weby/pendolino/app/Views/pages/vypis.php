<div id="container_style" class="container">
    <table class="table table-striped table-bordered">
        <tr>
            <th>název</th>
            <th>delka</th>
            <th>zanr</th>
            <th>typ</th>
         </tr>
        <?php foreach($zmenit as $film): ?>
        <tr>
            <td><?php echo $film->nazev; ?></td>
            <td><?php echo $film->delka." min"; ?></td>
            <td><?php echo $film->zanr; ?></td>
            <td><?php echo $film->typ; ?></td>
         </tr>
         <?php endforeach; ?>
    </table>
</div>