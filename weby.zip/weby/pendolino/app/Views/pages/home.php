<center>     
        
<H1> Kino Staré Město </H1>
<img src="https://www.informuji.cz/data/2018218190541.jpg"/>

</center>