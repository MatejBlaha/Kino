<style>
.obsah{
    float: center;
    width: 98%;
    height: 85%;
    
}
a{
  color: #222b6e;
}
</style>
<div class="container obsah">
  <table class="table">
  <thead>
    <tr>
      <th scope="col">Název</th>
      <th scope="col">Sál</th>
      <th scope="col">Promítání</th>
      <th scope="col">Vstupenky</th>
      <th scope="col">Herci ve filmu</th>
      <th scope="col">Typ</th>
    </tr>
  </thead>
  <tbody>
     <?php foreach($filmy as $a): ?>
      <tr>
            <td><a href="<?php echo base_url()?>/Kino/vypisOprav/<?php echo $a['idautomobily']?>">
              <?php echo $a['nazev'];?> 
              </a>      
            </td>
            <td> 
                <?php echo $a['sal']; ?>
            </td>
            <td> 
                <?php echo $a['promitani']; ?>
            </td>
            <td> 
                <?php echo $a['vstupenky']; ?>
            </td>
            <td> 
                <?php echo $a['herci_ve_filmu']; ?>
            </td>
            <td> 
                <?php echo $a['typ']; ?>
            </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>